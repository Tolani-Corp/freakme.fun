
## 🛡 Contributor Certificate

All commits to this repository require a signed Developer Certificate of Origin (DCO).

![DCO Required](https://img.shields.io/badge/DCO-Required-green?style=flat-square)
