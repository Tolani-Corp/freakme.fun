# 🍑 FreakMe.fun

**Public Web2+Web3 Hybrid Platform**  
Home of Solo, Scenes, NFT Rewards, DAO Voting & Verified Models

---

## 🎯 Mission
Deliver a modern, fast-loading, wallet-ready user experience for **FreakMe.fun** blending:
- ✅ Web2 onboarding (Notion + Make.com)
- 🧠 Web3 access (WalletConnect, NFT Gating, DAO tools)
- 🎬 Solo + Model Content (Watch-Burn-Earn model)

---

## 🧩 Tech Stack

| Layer     | Tool |
|-----------|------|
| Frontend  | Next.js (App Router)  
| Styling   | Tailwind CSS  
| CMS       | Notion (Model DB)  
| Automation | Make.com (form → task logic)  
| Hosting   | Vercel (staging + live)  
| Web3      | RainbowKit + Wagmi + WalletConnect  
| Storage   | Google Drive (Web2), IPFS/Pinata (Web3)  

---

## 📂 Project Structure

```bash
/app         → Routes (models, dao, freak-me)
/components  → UI (button, form, header)
/public      → Static assets (logo, fallback)
/styles      → Tailwind configs
```

---

## 📦 Setup

```bash
npm install
npm run dev
```

Create a `.env.local` with:

```env
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=...
NOTION_API_KEY=...
NOTION_MODELS_DB_ID=...
```

---

## 📜 Deployment

This repo auto-deploys via Vercel:
- **Staging:** freakme-fun.vercel.app
- **Live:** freakme.fun (manual DNS update pending)

---

## 🧑‍💻 Action Officer

**Assigned:** `@manus`  
**Role:** GitHub + Vercel access, model pages, DAO routes, asset syncing  
**Reporting:** Push updates weekly. All builds must be commit-staged via PR.

---

## 📌 Roadmap

- [ ] `/models` creator showcase
- [ ] `/watch-burn-earn` content loop
- [ ] `/dao` connected to smart contract
- [ ] `/wallet-only` page gated via NFT or address

---

## 🧠 Notes

- Never push `.env.local`
- Keep all image/video assets external (GDrive or IPFS)
- Manus is authorized to merge changes + control CI/CD
